import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.awt.Color;

// **NEW CLASS**
// Server Class
public class Server{

  private int port;
  private List<User> clients;
  private ServerSocket server;

  public static void main(String[] args) throws IOException{
    new Server(12345).run();
  }

  public Server(int port){
	  this.port = port;
	  this.clients = new ArrayList<User>();
	  }

  public void run() throws IOException{
	  server = new ServerSocket(port){
		  protected void finalize() throws IOException{
			  this.close();
			  }
		};
		
    System.out.println("Port 12345 available");

    while (true){
      // accepts new client
      Socket client = server.accept();

      // get username of client
      String username = (new Scanner ( client.getInputStream() )).nextLine();

      System.out.println("New Client: \"" + username + "\"\n\t     Host:" + client.getInetAddress().getHostAddress());

      // create new user
      User newUser = new User(client, username);

      // send message to list that new client connected
      this.clients.add(newUser);

      // incoming messages handling
      new Thread(new UserHandler(this, newUser)).start();
    }
  }

  // remove a user from the list
  public void removeUser(User user){
    this.clients.remove(user);
  }

  // send new messages to all users
  public void broadcastMessages(String msg, User userSender) {
    for (User client : this.clients) {
      client.getOutStream().println(
          userSender.toString() + "<span>: " + msg+"</span>");
    }
  }

  // send list of clients to all users and displays them in username list
  public void broadcastAllUsers(){
    for (User client : this.clients) {
      client.getOutStream().println(this.clients);
    }
  }

  // sends message to a user privately
  public void sendMessageToUser(String msg, User userSender, String user){
    boolean find = false;
    for (User client : this.clients){
      if (client.getUsername().equals(user) && client != userSender){
        find = true;
        userSender.getOutStream().println(userSender.toString() + " -> " + client.toString() +": " + msg);
        client.getOutStream().println("(<b>Private</b>)" + userSender.toString() + "<span>: " + msg+"</span>");
      }
    }
	
    if (!find){
      userSender.getOutStream().println(userSender.toString() + " -> (<b>no one!</b>): " + msg);
    }
  }
}

// **NEW CLASS**
// UserHandler Class

class UserHandler implements Runnable{

  private Server server;
  private User user;

  public UserHandler(Server server, User user){
    this.server = server;
    this.user = user;
    this.server.broadcastAllUsers();
  }

  public void run(){
    String message;

    // when there is a new message, broadcast to all
    Scanner sc = new Scanner(this.user.getInputStream());
    while (sc.hasNextLine()){
      message = sc.nextLine();

      // Send a message privately when '@' symbol is used
      if (message.charAt(0) == '@'){
        if(message.contains(" ")){
          System.out.println("private msg : " + message);
          int firstSpace = message.indexOf(" ");
          String userPrivate= message.substring(1, firstSpace);
          server.sendMessageToUser(
              message.substring(
                firstSpace+1, message.length()
                ), user, userPrivate
              );
        }
      }
	  else{
        // update user list
        server.broadcastMessages(message, user);
      }
    }
    // removes user when disconnecting
    server.removeUser(user);
    this.server.broadcastAllUsers();
    sc.close();
  }
}


// **NEW CLASS**
// User Class
class User{
  private static int nbUser = 0;
  private int userId;
  private PrintStream streamOut;
  private InputStream streamIn;
  private String username;
  private Socket client;
  private String color;

  // constructor
  public User(Socket client, String name) throws IOException{
    this.streamOut = new PrintStream(client.getOutputStream());
    this.streamIn = client.getInputStream();
    this.client = client;
    this.username = name;
    this.userId = nbUser;
    this.color = ColorInt.getColor(this.userId);
    nbUser += 1;
  }


  public PrintStream getOutStream(){
    return this.streamOut;
  }

  public InputStream getInputStream(){
    return this.streamIn;
  }

  public String getUsername(){
    return this.username;
  }

  // print username with a color
  public String toString(){

    return "<u><span style='color:"+ this.color
      +"'>" + this.getUsername() + "</span></u>";

  }
}

// **NEW CLASS**
// ColorInt CLass
class ColorInt {
    public static String[] mColors = {
            "#3079ab", // dark blue
            "#e15258", // red
            "#f9845b", // orange
            "#7d669e", // purple
            "#53bbb4", // aqua
            "#51b46d", // green
            "#e0ab18", // mustard
            "#f092b0", // pink
            "#e8d174", // yellow
            "#e39e54", // orange
            "#d64d4d", // red
            "#4d7358", // green
    };

    public static String getColor(int i) {
        return mColors[i % mColors.length];
    }
}